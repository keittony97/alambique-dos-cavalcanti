---
name: Cavalcanti Haute Terroir
colors:
  surface: '#fff9eb'
  surface-dim: '#dfdacc'
  surface-bright: '#fff9eb'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f9f3e5'
  surface-container: '#f3eddf'
  surface-container-high: '#eee8da'
  surface-container-highest: '#e8e2d4'
  on-surface: '#1e1c13'
  on-surface-variant: '#57423e'
  inverse-surface: '#333027'
  inverse-on-surface: '#f6f0e2'
  outline: '#8b716d'
  outline-variant: '#dec0bb'
  surface-tint: '#a7392b'
  primary: '#6b0c05'
  on-primary: '#ffffff'
  primary-container: '#8b2519'
  on-primary-container: '#ffa293'
  inverse-primary: '#ffb4a8'
  secondary: '#3a684c'
  on-secondary: '#ffffff'
  secondary-container: '#b9ebc8'
  on-secondary-container: '#3f6c50'
  tertiary: '#4d2d00'
  on-tertiary: '#ffffff'
  tertiary-container: '#6c4100'
  on-tertiary-container: '#f1ad5b'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdad4'
  primary-fixed-dim: '#ffb4a8'
  on-primary-fixed: '#410000'
  on-primary-fixed-variant: '#862116'
  secondary-fixed: '#bceecb'
  secondary-fixed-dim: '#a1d2af'
  on-secondary-fixed: '#002110'
  on-secondary-fixed-variant: '#224f35'
  tertiary-fixed: '#ffddba'
  tertiary-fixed-dim: '#ffb866'
  on-tertiary-fixed: '#2b1700'
  on-tertiary-fixed-variant: '#673d00'
  background: '#fff9eb'
  on-background: '#1e1c13'
  surface-variant: '#e8e2d4'
  parchment-base: '#F7F4EB'
  parchment-surface: '#EDE7D9'
  parchment-dark: '#DFD7C2'
  terracotta-rich: '#8B2519'
  terracotta-burnt: '#A63A22'
  canopy-green: '#2D5A3F'
  copper-still: '#C98A3C'
  ink-charcoal: '#1F1916'
  ink-muted: '#6E6359'
  border-brass: '#D1C3A5'
typography:
  display-hero:
    fontFamily: Playfair Display
    fontSize: 64px
    fontWeight: '400'
    lineHeight: 72px
    letterSpacing: -0.02em
  display-hero-mobile:
    fontFamily: Playfair Display
    fontSize: 38px
    fontWeight: '400'
    lineHeight: 46px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Playfair Display
    fontSize: 40px
    fontWeight: '400'
    lineHeight: 48px
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Playfair Display
    fontSize: 28px
    fontWeight: '400'
    lineHeight: 36px
  headline-md:
    fontFamily: Playfair Display
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
  headline-sm:
    fontFamily: Playfair Display
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 30px
  title-editorial:
    fontFamily: Playfair Display
    fontSize: 20px
    fontWeight: '400'
    lineHeight: 28px
    letterSpacing: 0.01em
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 20px
  spec-data:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.18em
  label-vintage:
    fontFamily: Plus Jakarta Sans
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.22em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 3rem
  margin-mobile: 1.25rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.75rem
  space-xl: 3rem
---

## Brand & Style

This design system elevates artisanal sugarcane spirits into the realm of rare, collectible luxury. It bridges traditional Brazilian alambique heritage with contemporary editorial restraint, appealing to connoisseurs of fine spirits, sommeliers, and collectors of craft gastronomy.

The visual direction merges **tactile heritage** with **refined editorial minimalism**:
- **Tactility & Heritage:** Rooted in textured parchment grounds, warm copper pot still undertones, and botanical engraving lines reminiscent of hand-pressed spirit labels.
- **Editorial Luxury:** Generous whitespace, disciplined hairline borders, fine filigree dividers, and high-contrast typography evoke the quiet gravitas of centuries-old European houses and private estates.
- **Atmosphere:** Warm, sunlit colonial hacienda meets precision apothecary craft—evoking aged wood, sugarcane terroir, polished brass fittings, and pure craft distillation.

## Colors

The palette draws directly from the artisanal distillation lifecycle:
- **Primary (`#8B2519` Terracotta / Amber):** Represents aged cask maturation, slow copper pot condensation, and the brand mark. Used for lead focal points, insignia, primary buttons, and title accents.
- **Secondary (`#2D5A3F` Sugarcane Forest Green):** Evokes the estate’s organic cane fields and the classic label ribbon banner. Applied to sensory tags, botanical highlights, badges, and secondary callouts.
- **Tertiary (`#C98A3C` Polished Copper / Antique Brass):** The signature metallic tone of the distillation still. Used for fine hairline rules, bespoke icons, crest detailing, and metallic trims.
- **Neutral (`#EDE7D9` / `#F7F4EB` Warm Parchment):** The foundation surfaces, replacing sterile white with organic, fiber-rich warmth that anchors typography and amber bottle photography naturally.
- **Ink Charcoal (`#1F1916`):** Replaces pure black to ensure editorial reading contrast without visual harshness against parchment grounds.

## Typography

The typographical architecture juxtaposes romantic 19th-century spirit label heritage with contemporary Swiss informational design:

- **Display & Headlines (Playfair Display):** Selected for its razor-sharp serifs, romantic ball terminals, and expressive italic forms. It provides the authoritative storytelling required for master distiller notes, heritage provenance statements, and product narratives.
- **Specifications & Body (Plus Jakarta Sans):** Provides an architectural, balanced grotesque counterpart. Its clean geometry makes bottle metrics (`910 ML`, `38% VOL`, `DESDE 2026`), tasting notes, and laboratory distillation metrics crisp, legible, and unpretentious.
- **Editorial Micro-Typo:** Technical labels, batch tracking, and geographical indicators are set in uppercase with tracking between `+0.18em` and `+0.22em`, echoing stamped vintage barrel stencils and certificate seal engraving.

## Layout & Spacing

The layout is built on a 12-column asymmetric fluid grid on desktop, shifting to a 6-column grid on tablet, and a single-column rhythm on mobile:

- **Desktop (1200px+):** Generous 48px outer canvas margins. Hero units feature an offset two-column split: left column for sculptural bottle imagery accompanied by artisanal seal stamps, right column dedicated to editorial headlines, vintage descriptors, and three-column specification tickers (`910 ML` | `38% VOL` | `DESDE 2026`).
- **Tablet (768px - 1199px):** 32px margins with responsive side-by-side reflow. Product specifications shift to a horizontal summary panel bordered by antique hairline rules.
- **Mobile (<768px):** 20px margins with central alignment. The bottle image commands central staging with floating copper-rimmed status badges (`EM BREVE` / `LOTE Nº 01`). Technical specs adopt a stacked 3-cell card structure.
- **Ornamental Spacing:** Section dividers feature central lozenge/diamond glyphs flanked by fine copper lines (`border-brass`), requiring at least `space-xl` vertical isolation above and below.

## Elevation & Depth

Visual depth avoids cold, modern drop shadows in favor of warm, tactile physical light models:

- **Tonal Layers:** Elevation is primarily achieved through surface stepping (`parchment-base` `#F7F4EB` to `parchment-surface` `#EDE7D9` to raised cards in `#FFFFFF`).
- **Amber Glow Shadows:** For the bottle showcase and signature interactive cards, cast shadows utilize low-opacity amber-tinted blurs: `0 24px 48px -12px rgba(139, 37, 25, 0.14)` and `0 8px 16px -4px rgba(45, 90, 63, 0.08)`. This mimics warm sunlight passing through aged spirit glass onto linen.
- **Framed Engraving Borders:** Elements gain definition via 1px crisp borders using `border-brass` (`#D1C3A5`) or subtle double-rule borders reminiscent of certificates and currency engraving.

## Shapes

The design system employs a **Soft (Level 1)** corner philosophy. Sharp or excessively rounded modern pill forms disrupt historical luxury; subtly softened rectangles honor hand-cut label edges, letterpress paper stock, and copper architectural plaques:

- **Base Radius (0.25rem / 4px):** Applied to primary buttons, interactive cards, specification tiles, and input containers.
- **Sub-elements (0.125rem / 2px):** Applied to internal tags, copper brackets, and tasting note chips.
- **Circular Heritage Seals:** Status medallions (such as the wax-style `EM BREVE` badge and distillery seal) remain purely circular (`border-radius: 9999px`) with concentric hairline rings.

## Components

### Buttons
- **Primary (Artisanal Wax):** Solid fill `#8B2519` (Terracotta) with cream typography (`#F7F4EB`), 4px border radius, uppercase `spec-data` styling, 18px horizontal padding, and subtle hover transition to `#A63A22`.
- **Secondary (Brass Hairline):** Transparent background with 1px border in `#C98A3C`, text in `#8B2519`. On hover, fills with a light parchment wash (`rgba(201, 138, 60, 0.08)`).
- **Botanical Action:** Solid `#2D5A3F` for terroir actions (harvest reports, organic certification modals).

### Badges & Medallions
- **Wax & Seal Medallion:** Circular floating badge styled after vintage estate stamps. Double concentric ring border in `#8B2519` with tilted italic Playfair serif copy (`Em Breve` or `Edição Limitada`).
- **Terroir Ribbon Chip:** Styled after the botanical ribbon from the bottle label. Background in `#2D5A3F`, crisp white or cream small caps lettering with fishtail border accents.

### Specification Cards & Data Grids
- **Bottle Metrics Ticker:** Three-column layout separated by delicate 1px `#D1C3A5` vertical rules. Displays metric value in bold Plus Jakarta Sans (`910 ML`, `38% VOL`, `2026`) topped by uppercase micro-labels (`VOLUME`, `TEOR ALCOÓLICO`, `SAFRA`).
- **Artisanal Profile Card:** Parchment-surface card (`#EDE7D9`) bounded by a 1px border, featuring corner bracket ornaments in `#C98A3C` and woodcut-style sugarcane motif illustrations.

### Form Inputs
- **Inquiry & Allocation Fields:** Background in `#FFFFFF` with 1px hairline border in `#D1C3A5`. On focus, shifts to a copper glow ring (`1px solid #C98A3C`) with 0 0 0 2px `rgba(201, 138, 60, 0.15)`. Labels sit top-aligned in `spec-data` uppercase.

### Editorial Dividers
- **Diamond Filigree Separator:** A horizontal hairline rule interrupted in the dead center by an amber or terracotta diamond lozenge (`◆`), providing classic typographic cadence between bottle exploration and master distiller chronicles.